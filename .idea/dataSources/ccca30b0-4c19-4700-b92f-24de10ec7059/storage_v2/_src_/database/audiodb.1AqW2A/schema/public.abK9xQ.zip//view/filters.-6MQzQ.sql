create view filters(tag_id, category_name, tag_name) as
SELECT tags.id           AS tag_id,
       tag_category.name AS category_name,
       tags.name         AS tag_name
FROM tags
         JOIN tag_category ON tag_category.id = tags.category_id;

alter table filters
    owner to postgres;

