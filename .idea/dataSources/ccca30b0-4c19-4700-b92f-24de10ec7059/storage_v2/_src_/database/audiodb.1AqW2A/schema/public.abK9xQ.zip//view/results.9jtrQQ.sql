create view results(id, name, description, audio_date, upload_date, transcript_text) as
SELECT audio.id,
       audio.name,
       audio.description,
       audio.audio_date,
       audio.upload_date,
       transcripts.text AS transcript_text
FROM audio
         JOIN transcripts ON transcripts.audio_id = audio.id
WHERE transcripts.is_latest = true;

alter table results
    owner to postgres;

