create view admin_transcript_edit_requests
            (request_id, user_id, transcript_id, audio_name, old_text, new_text, edit_comment, request_time,
             approval_status) as
SELECT user_edit_request.id               AS request_id,
       user_edit_request.user_id,
       transcripts.id                     AS transcript_id,
       audio.name                         AS audio_name,
       transcripts.text                   AS old_text,
       user_edit_request.text             AS new_text,
       user_edit_request.edit_comment,
       user_edit_request.create_time      AS request_time,
       user_edit_request.request_approved AS approval_status
FROM user_edit_request
         JOIN transcripts ON user_edit_request.transcript_id = transcripts.id
         JOIN audio ON audio.id = transcripts.audio_id
WHERE user_edit_request.request_approved IS NULL;

alter table admin_transcript_edit_requests
    owner to postgres;

